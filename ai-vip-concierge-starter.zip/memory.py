from langchain.memory import ConversationBufferMemory

def get_memory():
    return ConversationBufferMemory()
