# Заготовка для Airtable
# Хранение VIP-профилей, предпочтений и истории общения

def fetch_user_preferences(user_id):
    return {
        "preferred_cuisine": "Japanese",
        "last_restaurant": "Zuma",
        "language": "English"
    }
