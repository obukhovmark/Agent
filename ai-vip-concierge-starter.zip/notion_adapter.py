# Заготовка для интеграции с Notion
# Можно использовать для хранения истории клиентов, профилей и задач

def save_to_notion(user_id, message):
    pass  # TODO: интеграция с Notion API
